BRAIN POWER KIDS - SCHOOL EDITION VERSION 2
Success Kings and Queens Schools | Grades 4, 5 and 6

FEATURES
- Puzzle Palace, Pun & Word Play, Tongue Twister Tower
- Grade-specific games with an expanded library of 75+ activities
- Learner profiles and personal progress stored on this device
- Stars, badges and printable achievement certificates
- Teacher PIN gate (first-use PIN 2468; change after sign-in)
- Teacher class score tracker
- Installable Android PWA with offline caching after first successful load

ANDROID INSTALLATION
1. Host all files in this folder on an HTTPS web host.
2. Open the hosted link in Chrome on Android.
3. Tap Install when offered, or Chrome menu > Install app / Add to Home screen.
4. Open from the home screen. Core app files are cached after the first successful load.

LIMITATIONS
- This is an installable web app, not a native APK or Google Play release.
- Learner profiles, scores and class results stay on the current device/browser.
- Teacher PIN is a simple local access gate, not secure server authentication.
- A school-wide online leaderboard and secure accounts require a hosted backend/database and deployment setup.
- Tongue-twister completion is self-reported; a teacher/partner should verify it.
