@echo off
setlocal
cd /d "%~dp0"
echo ==============================================
echo  BRAIN POWER KIDS - WINDOWS APK BUILD
echo ==============================================
where java >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java was not found. Install Android Studio and use its bundled JDK 17.
  pause
  exit /b 1
)
where gradle >nul 2>nul
if errorlevel 1 (
  echo ERROR: Gradle command was not found.
  echo Open this folder in Android Studio, allow Gradle sync, then use Build ^> Build APK(s).
  echo Alternatively, upload this project to a GitHub repository and run the Build Brain Power Kids APK workflow.
  pause
  exit /b 1
)
echo Building debug APK...
gradle --no-daemon assembleDebug
if errorlevel 1 (
  echo BUILD FAILED. Check the error messages above.
  pause
  exit /b 1
)
echo.
echo BUILD SUCCEEDED.
echo APK: app\build\outputs\apk\debug\app-debug.apk
pause
