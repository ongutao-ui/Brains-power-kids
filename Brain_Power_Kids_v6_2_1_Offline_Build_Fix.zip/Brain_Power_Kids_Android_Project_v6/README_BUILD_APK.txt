BRAIN POWER KIDS — ANDROID STUDIO PROJECT V6.2 (OFFLINE-FIRST)
School: Success Kings and Queens Schools
Application ID: ke.co.successkings.brainpowerkids

OFFLINE OPERATION
- All learner activities, logo and application screens are bundled in app/src/main/assets.
- The Android manifest does not request INTERNET permission.
- No server, account service, network connection or cloud sync is used.
- Teacher registration and login use a teacher-created username and password.
- Learner profiles and scores are saved locally on the same device using WebView local storage.
- Local records are not backed up or automatically transferred to another phone.

IMPORTANT SECURITY LIMITATION
This is a classroom prototype. Teacher passwords are stored in local app storage and are not securely hashed. Use a unique, non-sensitive test password. Do not store sensitive learner information or treat local login as secure identity verification. A secure authentication and school data backend is required for production deployment.

BUILD A DEBUG APK
1. Install Android Studio on Windows and install Android SDK Platform 35 and Build Tools 35.x.
2. Open this project folder (the folder containing settings.gradle) in Android Studio.
3. Use JDK 17 (Android Studio's bundled JDK is suitable).
4. Allow Gradle sync. Android Gradle Plugin 8.7.3 requires a compatible Gradle 8.9 installation; Android Studio can download it.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK is normally app/build/outputs/apk/debug/app-debug.apk.

CREATE A SIGNED RELEASE APK
1. Select Build > Generate Signed Bundle / APK > APK.
2. Create and securely back up a private keystore. Never share its password or private key.
3. Select release and complete the signing wizard.
4. Install on a test Android phone and test launch, offline games, teacher username login, learner records and score persistence.

PROJECT CONFIGURATION
- Android Gradle Plugin 8.7.3; Kotlin 2.0.21; compile/target SDK 35; minimum SDK 23.
- Android WebView loads the bundled local index.html.
- This source package is not itself a compiled APK. Compilation, signing and physical-device installation still require Android SDK/build tools and an Android device.
